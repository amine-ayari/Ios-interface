//
//  user.swift
//  userinterface
//
//  Created by Mac Mini 1 on 16/11/2023.
//

import Foundation

struct user : Codable{
    var email : String
    var firstname: String
    var lastname: String
    var phone : Int
    var pssword : String
    var img : String
    var wallet : String
    var adresse : String
}
