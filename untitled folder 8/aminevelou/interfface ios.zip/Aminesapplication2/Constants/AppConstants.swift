//
//  AppConstants.swift
//  Aminesapplication2

import Foundation

struct AppConstants {
    static let serverURL: String = ""
}
