import SwiftUI

struct AccountCreationView: View {
    @StateObject var accountCreationViewModel = AccountCreationViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                HStack {
                    HStack {
                        Image("img_leftside")
                            .resizable()
                            .frame(width: 54.0, height: getRelativeHeight(21.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .clipShape(Capsule())
                        Spacer()
                        Image("img_rightside")
                            .resizable()
                            .frame(width: 66.0, height: getRelativeHeight(11.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.top, getRelativeHeight(5.0))
                            .padding(.bottom, getRelativeHeight(4.0))
                    }
                    .frame(width: getRelativeWidth(392.0), height: getRelativeHeight(21.0),
                           alignment: .leading)
                }
                .frame(width: 392.0, height: getRelativeHeight(21.0), alignment: .leading)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                ZStack(alignment: .topTrailing) {
                    Image("img_ellipse5")
                        .resizable()
                        .frame(width: 150.0, height: getRelativeWidth(150.0), alignment: .center)
                        .scaledToFit()
                        .clipShape(Circle())
                        .clipShape(Circle())
                    Button(action: {}, label: {
                        Image("img_group754")
                    })
                    .frame(width: 30.0, height: getRelativeWidth(30.0), alignment: .center)
                    .background(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                               bottomRight: 15.0)
                            .fill(ColorConstants.BlueA700))
                    .padding(.bottom, getRelativeHeight(115.0))
                    .padding(.leading, getRelativeWidth(118.0))
                }
                .hideNavigationBar()
                .frame(width: 150.0, height: getRelativeWidth(150.0), alignment: .center)
                .padding(.top, getRelativeHeight(38.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack(alignment: .leading, spacing: 0) {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblFirstName)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 78.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        Group {
                            HStack {
                                TextField(StringConstants.kMsgEnterFirstNam,
                                          text: $accountCreationViewModel.group10198Text)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Bluegray200)
                                    .padding()
                                    .keyboardType(.alphabet)
                            }
                            .onChange(of: accountCreationViewModel.group10198Text) { newValue in

                                accountCreationViewModel.isValidGroup10198Text = newValue
                                    .isText(isMandatory: false)
                            }
                            .frame(width: 396.0, height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(9.0))
                            if !accountCreationViewModel.isValidGroup10198Text {
                                Text("Please enter valid text.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .frame(width: 396.0, height: getRelativeHeight(44.0),
                                           alignment: .leading)
                            }
                        }
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .leading)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                    .padding(.top, getRelativeHeight(4.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblLastName)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 79.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        Group {
                            HStack {
                                TextField(StringConstants.kLblEnterLastName,
                                          text: $accountCreationViewModel.group10198oneText)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Bluegray200)
                                    .padding()
                                    .keyboardType(.alphabet)
                            }
                            .onChange(of: accountCreationViewModel.group10198oneText) { newValue in

                                accountCreationViewModel.isValidGroup10198oneText = newValue
                                    .isText(isMandatory: false)
                            }
                            .frame(width: 396.0, height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(9.0))
                            if !accountCreationViewModel.isValidGroup10198oneText {
                                Text("Please enter valid text.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .frame(width: 396.0, height: getRelativeHeight(44.0),
                                           alignment: .leading)
                            }
                        }
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .leading)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                    .padding(.top, getRelativeHeight(20.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblMobileNumber)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 112.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        Group {
                            HStack {
                                TextField(StringConstants.kMsgEnterMobileNu,
                                          text: $accountCreationViewModel.group10198twoText)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Bluegray200)
                                    .padding()
                                    .keyboardType(.phonePad)
                            }
                            .onChange(of: accountCreationViewModel.group10198twoText) { newValue in

                                accountCreationViewModel.isValidGroup10198twoText = newValue
                                    .isValidPhone(isMandatory: false)
                            }
                            .frame(width: 396.0, height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(9.0))
                            if !accountCreationViewModel.isValidGroup10198twoText {
                                Text("Please enter valid phone number.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .frame(width: 396.0, height: getRelativeHeight(44.0),
                                           alignment: .leading)
                            }
                        }
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .leading)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                    .padding(.top, getRelativeHeight(20.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblEmailId)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 58.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        Group {
                            HStack {
                                TextField(StringConstants.kLblEnterEmailId,
                                          text: $accountCreationViewModel.group10198threeText)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Bluegray200)
                                    .padding()
                                    .keyboardType(.emailAddress)
                            }
                            .onChange(of: accountCreationViewModel
                                .group10198threeText) { newValue in

                                    accountCreationViewModel.isValidGroup10198threeText = newValue
                                        .isValidEmail(isMandatory: true)
                            }
                            .frame(width: 396.0, height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(9.0))
                            if !accountCreationViewModel.isValidGroup10198threeText {
                                Text("Please enter valid email.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .frame(width: 396.0, height: getRelativeHeight(44.0),
                                           alignment: .leading)
                            }
                        }
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .leading)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                    .padding(.top, getRelativeHeight(20.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblSetPassword)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 98.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        Group {
                            HStack {
                                SecureField(StringConstants.kLblSetPassword,
                                            text: $accountCreationViewModel.group10198fourText)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Bluegray200)
                                    .padding()
                                    .keyboardType(.default)
                            }
                            .onChange(of: accountCreationViewModel.group10198fourText) { newValue in

                                accountCreationViewModel.isValidGroup10198fourText = newValue
                                    .isValidPassword(isMandatory: true)
                            }
                            .frame(width: 396.0, height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(9.0))
                            if !accountCreationViewModel.isValidGroup10198fourText {
                                Text("Please enter valid password.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .frame(width: 396.0, height: getRelativeHeight(44.0),
                                           alignment: .leading)
                            }
                        }
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .leading)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                    .padding(.top, getRelativeHeight(20.0))
                    Button(action: {}, label: {
                        HStack(spacing: 0) {
                            Text(StringConstants.kLblCreateAccount)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .fontWeight(.medium)
                                .padding(.horizontal, getRelativeWidth(30.0))
                                .padding(.vertical, getRelativeHeight(17.0))
                                .foregroundColor(ColorConstants.WhiteA700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: 396.0, height: getRelativeHeight(50.0),
                                       alignment: .center)
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0)
                                        .fill(ColorConstants.BlueA700))
                                .padding(.top, getRelativeHeight(24.0))
                        }
                    })
                    .frame(width: 396.0, height: getRelativeHeight(50.0), alignment: .center)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0)
                            .fill(ColorConstants.BlueA700))
                    .padding(.top, getRelativeHeight(24.0))
                }
                .frame(width: 396.0, height: getRelativeHeight(508.0), alignment: .center)
                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                           bottomRight: 6.0))
                .padding(.vertical, getRelativeHeight(24.0))
                .padding(.horizontal, getRelativeWidth(16.0))
            }
            .frame(width: 310.0, alignment: .topLeading)
            .background(ColorConstants.Gray51)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: 310.0, height: UIScreen.main.bounds.height)
        .background(ColorConstants.Gray51)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct AccountCreationView_Previews: PreviewProvider {
    static var previews: some View {
        AccountCreationView()
    }
}
