import SwiftUI

struct RowtoggleCell: View {
    var body: some View {
        HStack {
            HStack {
                Button(action: {}, label: {
                    Image("img_group2456")
                })
                .frame(width: getRelativeWidth(28.0), height: getRelativeWidth(30.0),
                       alignment: .center)
                .background(RoundedCorners(topLeft: 15.0, topRight: 15.0, bottomLeft: 15.0,
                                           bottomRight: 15.0)
                        .fill(ColorConstants.Blue50))
                Text(StringConstants.kLblInstagram)
                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(18.0)))
                    .fontWeight(.medium)
                    .foregroundColor(ColorConstants.Black900)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: getRelativeWidth(82.0), height: getRelativeHeight(18.0),
                           alignment: .leading)
                    .padding(.leading, getRelativeWidth(12.0))
            }
            .frame(width: getRelativeWidth(124.0), height: getRelativeHeight(30.0),
                   alignment: .leading)
            Toggle("", isOn: .constant(true))
                .toggleStyle(SwitchToggleStyle(tint: ColorConstants.Gray51))
                .frame(width: getRelativeWidth(43.0), height: getRelativeHeight(25.0),
                       alignment: .leading)
                .padding(.leading, getRelativeWidth(225.0))
        }
        .frame(width: getRelativeWidth(394.0), alignment: .leading)
        .hideNavigationBar()
    }
}

/* struct RowtoggleCell_Previews: PreviewProvider {

 static var previews: some View {
 			RowtoggleCell()
 }
 } */
