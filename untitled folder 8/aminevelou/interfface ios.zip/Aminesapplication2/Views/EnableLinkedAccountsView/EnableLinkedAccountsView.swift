import SwiftUI

struct EnableLinkedAccountsView: View {
    @StateObject var enableLinkedAccountsViewModel = EnableLinkedAccountsViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack(alignment: .leading, spacing: 0) {
                VStack {
                    HStack {
                        HStack {
                            Image("img_leftside")
                                .resizable()
                                .frame(width: 54.0, height: getRelativeHeight(21.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .clipShape(Capsule())
                            Spacer()
                            Image("img_rightside")
                                .resizable()
                                .frame(width: 66.0, height: getRelativeHeight(11.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(4.0))
                        }
                        .frame(width: getRelativeWidth(392.0), height: getRelativeHeight(21.0),
                               alignment: .leading)
                    }
                    .frame(width: 392.0, height: getRelativeHeight(21.0), alignment: .leading)
                    .padding(.leading, getRelativeWidth(5.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(21.0), alignment: .center)
                .padding(.top, getRelativeHeight(12.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        Image("img_arrowleft")
                            .resizable()
                            .frame(width: 12.0, height: getRelativeWidth(12.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            .onTapGesture {
                                self.presentationMode.wrappedValue.dismiss()
                            }
                        Text(StringConstants.kMsgEnableLinkedA)
                            .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(24.0)))
                            .fontWeight(.semibold)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 262.0, height: getRelativeHeight(24.0),
                                   alignment: .topLeading)
                            .padding(.leading, getRelativeWidth(49.0))
                    }
                    .frame(width: 323.0, height: getRelativeHeight(24.0), alignment: .leading)
                    .padding(.leading, getRelativeWidth(6.0))
                    .padding(.trailing, getRelativeWidth(6.0))
                    Text(StringConstants.kMsgSelectYourAcc)
                        .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(20.0)))
                        .fontWeight(.semibold)
                        .foregroundColor(ColorConstants.Bluegray900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: 186.0, height: getRelativeHeight(20.0),
                               alignment: .topLeading)
                        .padding(.top, getRelativeHeight(43.0))
                        .padding(.trailing, getRelativeWidth(10.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(87.0), alignment: .center)
                .padding(.top, getRelativeHeight(26.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack {
                    VStack(spacing: 0) {
                        ScrollView(.vertical, showsIndicators: false) {
                            LazyVStack {
                                ForEach(0 ... 4, id: \.self) { index in
                                    RowtoggleCell()
                                }
                            }
                        }
                    }
                    .frame(width: 396.0, alignment: .center)
                }
                .frame(width: 397.0, height: getRelativeHeight(246.0), alignment: .center)
                .padding(.vertical, getRelativeHeight(30.0))
                .padding(.horizontal, getRelativeWidth(16.0))
            }
            .frame(width: 310.0, alignment: .topLeading)
            .background(ColorConstants.Gray51)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: 310.0, height: UIScreen.main.bounds.height)
        .background(ColorConstants.Gray51)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct EnableLinkedAccountsView_Previews: PreviewProvider {
    static var previews: some View {
        EnableLinkedAccountsView()
    }
}
