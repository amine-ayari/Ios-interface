import Foundation
import SwiftUI

class EnableLinkedAccountsViewModel: ObservableObject {}
