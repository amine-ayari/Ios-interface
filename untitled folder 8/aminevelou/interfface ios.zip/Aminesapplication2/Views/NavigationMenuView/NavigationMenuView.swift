import SwiftUI

struct NavigationMenuView: View {
    @StateObject var navigationMenuViewModel = NavigationMenuViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                VStack {
                    Group {
                        HStack {
                            Image("img_81")
                                .resizable()
                                .frame(width: 48.0, height: getRelativeWidth(48.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipShape(Circle())
                                .clipShape(Circle())
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLblAshfakSayem)
                                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                    .fontWeight(.semibold)
                                    .foregroundColor(ColorConstants.Bluegray900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 103.0, height: getRelativeHeight(16.0),
                                           alignment: .topLeading)
                                    .padding(.trailing)
                                Text(StringConstants.kMsgAshfaksayemGma)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(12.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Bluegray400)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 138.0, height: getRelativeHeight(12.0),
                                           alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(8.0))
                            }
                            .frame(width: 138.0, height: getRelativeHeight(36.0),
                                   alignment: .bottom)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(4.0))
                            .padding(.leading, getRelativeWidth(12.0))
                        }
                        .frame(width: 262.0, height: getRelativeHeight(48.0), alignment: .center)
                        .padding(.top, getRelativeHeight(24.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            HStack {
                                Image("img_calendar")
                                    .resizable()
                                    .frame(width: 20.0, height: getRelativeWidth(20.0),
                                           alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                Text(StringConstants.kLblCalendar)
                                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                    .fontWeight(.semibold)
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 69.0, height: getRelativeHeight(16.0),
                                           alignment: .topLeading)
                                    .padding(.leading, getRelativeWidth(8.0))
                            }
                            .frame(width: 97.0, height: getRelativeHeight(20.0), alignment: .center)
                            .padding(.vertical, getRelativeHeight(15.0))
                            .padding(.leading, getRelativeWidth(14.0))
                            Spacer()
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLbl2)
                                        .font(FontScheme
                                            .kInterSemiBold(size: getRelativeHeight(10.0)))
                                        .fontWeight(.semibold)
                                        .padding(.horizontal, getRelativeWidth(6.0))
                                        .padding(.vertical, getRelativeHeight(4.0))
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: 20.0, height: getRelativeWidth(20.0),
                                               alignment: .center)
                                        .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                                   bottomLeft: 4.0,
                                                                   bottomRight: 4.0)
                                                .fill(ColorConstants.LightBlue100))
                                        .padding(.vertical, getRelativeHeight(15.0))
                                        .padding(.trailing, getRelativeWidth(12.0))
                                }
                            })
                            .frame(width: 20.0, height: getRelativeWidth(20.0), alignment: .center)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.LightBlue100))
                            .padding(.vertical, getRelativeHeight(15.0))
                            .padding(.trailing, getRelativeWidth(12.0))
                        }
                        .frame(width: 262.0, height: getRelativeHeight(50.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0)
                                .fill(ColorConstants.BlueA700))
                        .padding(.top, getRelativeHeight(32.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            HStack {
                                Image("img_iconoutline")
                                    .resizable()
                                    .frame(width: 16.0, height: getRelativeHeight(20.0),
                                           alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                Text(StringConstants.kLblRewards)
                                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                    .fontWeight(.semibold)
                                    .foregroundColor(ColorConstants.Bluegray700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 62.0, height: getRelativeHeight(16.0),
                                           alignment: .topLeading)
                                    .padding(.leading, getRelativeWidth(9.0))
                            }
                            .frame(width: 88.0, height: getRelativeHeight(20.0), alignment: .center)
                            Spacer()
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLbl2)
                                        .font(FontScheme
                                            .kInterSemiBold(size: getRelativeHeight(10.0)))
                                        .fontWeight(.semibold)
                                        .padding(.horizontal, getRelativeWidth(6.0))
                                        .padding(.vertical, getRelativeHeight(4.0))
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: 20.0, height: getRelativeWidth(20.0),
                                               alignment: .center)
                                        .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                                   bottomLeft: 4.0,
                                                                   bottomRight: 4.0)
                                                .fill(ColorConstants.Red200))
                                }
                            })
                            .frame(width: 20.0, height: getRelativeWidth(20.0), alignment: .center)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.Red200))
                        }
                        .frame(width: 238.0, height: getRelativeHeight(26.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0))
                        .padding(.top, getRelativeHeight(20.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Image("img_icon")
                                .resizable()
                                .frame(width: 16.0, height: getRelativeHeight(20.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Text(StringConstants.kLblAddress)
                                .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                .fontWeight(.semibold)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: 58.0, height: getRelativeHeight(16.0),
                                       alignment: .topLeading)
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.bottom, getRelativeHeight(5.0))
                                .padding(.leading, getRelativeWidth(9.0))
                                .padding(.trailing, getRelativeWidth(149.0))
                        }
                        .frame(width: 238.0, height: getRelativeHeight(26.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0))
                        .padding(.top, getRelativeHeight(32.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Image("img_union")
                                .resizable()
                                .frame(width: 20.0, height: getRelativeWidth(20.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Text(StringConstants.kMsgPaymentsMethod)
                                .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                .fontWeight(.semibold)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: 140.0, height: getRelativeHeight(16.0),
                                       alignment: .topLeading)
                                .padding(.top, getRelativeHeight(6.0))
                                .padding(.leading, getRelativeWidth(8.0))
                        }
                        .frame(width: 238.0, height: getRelativeHeight(26.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0))
                        .padding(.top, getRelativeHeight(32.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            HStack {
                                Image("img_icon_bluegray_700")
                                    .resizable()
                                    .frame(width: 20.0, height: getRelativeWidth(20.0),
                                           alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                Text(StringConstants.kLblOffers)
                                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                    .fontWeight(.semibold)
                                    .foregroundColor(ColorConstants.Bluegray700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 43.0, height: getRelativeHeight(16.0),
                                           alignment: .topLeading)
                                    .padding(.leading, getRelativeWidth(7.0))
                            }
                            .frame(width: 71.0, height: getRelativeHeight(20.0), alignment: .center)
                            Spacer()
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLbl2)
                                        .font(FontScheme
                                            .kInterSemiBold(size: getRelativeHeight(10.0)))
                                        .fontWeight(.semibold)
                                        .padding(.horizontal, getRelativeWidth(6.0))
                                        .padding(.vertical, getRelativeHeight(4.0))
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: 20.0, height: getRelativeWidth(20.0),
                                               alignment: .center)
                                        .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                                   bottomLeft: 4.0,
                                                                   bottomRight: 4.0)
                                                .fill(ColorConstants.GreenA100))
                                }
                            })
                            .frame(width: 20.0, height: getRelativeWidth(20.0), alignment: .center)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.GreenA100))
                        }
                        .frame(width: 238.0, height: getRelativeHeight(26.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0))
                        .padding(.top, getRelativeHeight(32.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Image("img_icon_bluegray_700_18x20")
                                .resizable()
                                .frame(width: 20.0, height: getRelativeHeight(18.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.vertical, getRelativeHeight(4.0))
                            Text(StringConstants.kLblReferAFriend)
                                .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                .fontWeight(.semibold)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: 101.0, height: getRelativeHeight(16.0),
                                       alignment: .topLeading)
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.bottom, getRelativeHeight(5.0))
                                .padding(.leading, getRelativeWidth(8.0))
                        }
                        .frame(width: 238.0, height: getRelativeHeight(26.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0))
                        .padding(.top, getRelativeHeight(32.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Image("img_rectangle159")
                                .resizable()
                                .frame(width: 18.0, height: getRelativeWidth(18.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Text(StringConstants.kLblSupport)
                                .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                .fontWeight(.semibold)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: 59.0, height: getRelativeHeight(16.0),
                                       alignment: .topLeading)
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(4.0))
                                .padding(.leading, getRelativeWidth(8.0))
                        }
                        .frame(width: 238.0, height: getRelativeHeight(26.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0))
                        .padding(.top, getRelativeHeight(32.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                    }
                    Group {
                        Divider()
                            .frame(width: 262.0, height: getRelativeHeight(2.0), alignment: .center)
                            .background(RoundedCorners(topLeft: 1.0, topRight: 1.0, bottomLeft: 1.0,
                                                       bottomRight: 1.0)
                                    .fill(ColorConstants.Bluegray1006c))
                            .padding(.top, getRelativeHeight(288.0))
                            .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            Image("img_uiiconhelpli")
                                .resizable()
                                .frame(width: 20.0, height: getRelativeWidth(20.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                            Text(StringConstants.kLblColourScheme)
                                .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(16.0)))
                                .fontWeight(.semibold)
                                .foregroundColor(ColorConstants.Bluegray700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: 112.0, height: getRelativeHeight(16.0),
                                       alignment: .topLeading)
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.bottom, getRelativeHeight(5.0))
                                .padding(.leading, getRelativeWidth(8.0))
                        }
                        .frame(width: 238.0, height: getRelativeHeight(26.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                   bottomRight: 8.0))
                        .padding(.top, getRelativeHeight(12.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                        HStack {
                            HStack {
                                Image("img_uiiconsunfil")
                                    .resizable()
                                    .frame(width: 21.0, height: getRelativeWidth(21.0),
                                           alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.leading, getRelativeWidth(27.0))
                                Text(StringConstants.kLblLight)
                                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(14.0)))
                                    .fontWeight(.semibold)
                                    .foregroundColor(ColorConstants.Bluegray700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 33.0, height: getRelativeHeight(14.0),
                                           alignment: .topLeading)
                                    .padding(.leading, getRelativeWidth(9.0))
                                    .padding(.trailing, getRelativeWidth(34.0))
                            }
                            .frame(width: 125.0, height: getRelativeHeight(32.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 16.0, topRight: 16.0,
                                                       bottomLeft: 16.0, bottomRight: 16.0)
                                    .fill(ColorConstants.WhiteA700))
                            .shadow(color: ColorConstants.Black9003f, radius: 8, x: 0, y: 4)
                            .padding(.vertical, getRelativeHeight(4.0))
                            .padding(.leading, getRelativeWidth(4.0))
                            Spacer()
                            HStack {
                                Image("img_subtractstrok")
                                    .resizable()
                                    .frame(width: 17.0, height: getRelativeWidth(17.0),
                                           alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                Text(StringConstants.kLblDark)
                                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(14.0)))
                                    .fontWeight(.semibold)
                                    .foregroundColor(ColorConstants.Bluegray700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: 31.0, height: getRelativeHeight(14.0),
                                           alignment: .topLeading)
                                    .padding(.leading, getRelativeWidth(11.0))
                            }
                            .frame(width: 60.0, height: getRelativeHeight(17.0), alignment: .center)
                            .clipShape(Capsule())
                            .padding(.vertical, getRelativeHeight(11.0))
                            .padding(.leading, getRelativeWidth(34.0))
                        }
                        .frame(width: 262.0, height: getRelativeHeight(40.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 20.0, topRight: 20.0, bottomLeft: 20.0,
                                                   bottomRight: 20.0)
                                .fill(ColorConstants.Gray200))
                        .padding(.vertical, getRelativeHeight(20.0))
                        .padding(.horizontal, getRelativeWidth(24.0))
                    }
                }
                .frame(width: 310.0, height: UIScreen.main.bounds.height, alignment: .topLeading)
                .background(ColorConstants.Gray50)
                .padding(.trailing, getRelativeWidth(118.0))
            }
            .frame(width: 310.0, height: UIScreen.main.bounds.height, alignment: .topLeading)
            .background(ColorConstants.Black900B2)
        }
        .frame(width: 310.0, height: UIScreen.main.bounds.height)
        .hideNavigationBar()
    }
}

struct NavigationMenuView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationMenuView()
    }
}
