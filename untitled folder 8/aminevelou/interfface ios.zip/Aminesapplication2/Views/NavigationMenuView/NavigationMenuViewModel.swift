import Foundation
import SwiftUI

class NavigationMenuViewModel: ObservableObject {}
