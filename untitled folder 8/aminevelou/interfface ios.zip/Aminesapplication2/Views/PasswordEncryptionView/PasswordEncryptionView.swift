import SwiftUI

struct PasswordEncryptionView: View {
    @StateObject var passwordEncryptionViewModel = PasswordEncryptionViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                HStack {
                    HStack {
                        Image("img_leftside")
                            .resizable()
                            .frame(width: 54.0, height: getRelativeHeight(21.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .clipShape(Capsule())
                        Spacer()
                        Image("img_rightside")
                            .resizable()
                            .frame(width: 66.0, height: getRelativeHeight(11.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.top, getRelativeHeight(5.0))
                            .padding(.bottom, getRelativeHeight(4.0))
                    }
                    .frame(width: getRelativeWidth(392.0), height: getRelativeHeight(21.0),
                           alignment: .leading)
                }
                .frame(width: 392.0, height: getRelativeHeight(21.0), alignment: .leading)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.leading, getRelativeWidth(21.0))
                .padding(.trailing, getRelativeWidth(14.0))
                Image("img_vector_blue_a700_66x54")
                    .resizable()
                    .frame(width: 54.0, height: getRelativeHeight(66.0), alignment: .center)
                    .scaledToFit()
                    .clipped()
                    .padding(.top, getRelativeHeight(293.0))
                    .padding(.horizontal, getRelativeWidth(21.0))
                Text(StringConstants.kMsgPasswordEncryp)
                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(24.0)))
                    .fontWeight(.semibold)
                    .foregroundColor(ColorConstants.Bluegray900)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: 229.0, height: getRelativeHeight(24.0), alignment: .topLeading)
                    .padding(.top, getRelativeHeight(32.0))
                    .padding(.horizontal, getRelativeWidth(21.0))
                Text(StringConstants.kMsgWeVeProtectec)
                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                    .fontWeight(.medium)
                    .foregroundColor(ColorConstants.Bluegray400)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.center)
                    .frame(width: 219.0, height: getRelativeHeight(37.0), alignment: .center)
                    .padding(.vertical, getRelativeHeight(27.0))
                    .padding(.horizontal, getRelativeWidth(21.0))
            }
            .frame(width: 310.0, alignment: .topLeading)
            .background(ColorConstants.Gray51)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: 310.0, height: UIScreen.main.bounds.height)
        .background(ColorConstants.Gray51)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct PasswordEncryptionView_Previews: PreviewProvider {
    static var previews: some View {
        PasswordEncryptionView()
    }
}
