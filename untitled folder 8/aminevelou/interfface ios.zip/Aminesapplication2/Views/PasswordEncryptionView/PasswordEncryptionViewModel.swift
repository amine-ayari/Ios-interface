import Foundation
import SwiftUI

class PasswordEncryptionViewModel: ObservableObject {}
