import Foundation
import SwiftUI

class PhoneVerificationViewModel: ObservableObject {
    @Published var otpviewOTP1: String = ""
}
