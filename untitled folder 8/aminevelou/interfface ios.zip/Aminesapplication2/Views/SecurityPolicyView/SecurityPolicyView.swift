import SwiftUI

struct SecurityPolicyView: View {
    @StateObject var securityPolicyViewModel = SecurityPolicyViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack(alignment: .leading, spacing: 0) {
                VStack {
                    HStack {
                        HStack {
                            Image("img_leftside")
                                .resizable()
                                .frame(width: 54.0, height: getRelativeHeight(21.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .clipShape(Capsule())
                            Spacer()
                            Image("img_rightside")
                                .resizable()
                                .frame(width: 66.0, height: getRelativeHeight(11.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(4.0))
                        }
                        .frame(width: getRelativeWidth(392.0), height: getRelativeHeight(21.0),
                               alignment: .leading)
                    }
                    .frame(width: 392.0, height: getRelativeHeight(21.0), alignment: .leading)
                    .padding(.leading, getRelativeWidth(5.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(21.0), alignment: .center)
                .padding(.top, getRelativeHeight(12.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        Image("img_arrowleft")
                            .resizable()
                            .frame(width: 12.0, height: getRelativeWidth(12.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.vertical, getRelativeHeight(3.0))
                            .onTapGesture {
                                self.presentationMode.wrappedValue.dismiss()
                            }
                        Text(StringConstants.kLblLogin)
                            .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(24.0)))
                            .fontWeight(.semibold)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 61.0, height: getRelativeHeight(24.0),
                                   alignment: .topLeading)
                            .padding(.leading, getRelativeWidth(150.0))
                    }
                    .frame(width: 223.0, height: getRelativeHeight(24.0), alignment: .leading)
                    .padding(.leading, getRelativeWidth(6.0))
                    .padding(.trailing, getRelativeWidth(6.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(24.0), alignment: .center)
                .padding(.top, getRelativeHeight(29.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgUsernameOrEma)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray800)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 137.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        Group {
                            HStack {
                                TextField(StringConstants.kMsgMichellerockGm,
                                          text: $securityPolicyViewModel.emailText)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Bluegray200)
                                    .padding()
                                    .keyboardType(.emailAddress)
                            }
                            .onChange(of: securityPolicyViewModel.emailText) { newValue in

                                securityPolicyViewModel.isValidEmailText = newValue
                                    .isValidEmail(isMandatory: true)
                            }
                            .frame(width: 396.0, height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(9.0))
                            if !securityPolicyViewModel.isValidEmailText {
                                Text("Please enter valid email.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .frame(width: 396.0, height: getRelativeHeight(44.0),
                                           alignment: .leading)
                            }
                        }
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .center)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(69.0), alignment: .center)
                .padding(.top, getRelativeHeight(39.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack(alignment: .leading, spacing: 0) {
                    Text(StringConstants.kLblPassword)
                        .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                        .fontWeight(.medium)
                        .foregroundColor(ColorConstants.Bluegray900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: 70.0, height: getRelativeHeight(16.0), alignment: .topLeading)
                        .padding(.trailing)
                }
                .frame(width: 397.0, height: getRelativeHeight(16.0), alignment: .center)
                .padding(.top, getRelativeHeight(20.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack {
                    Group {
                        HStack {
                            SecureField(StringConstants.kLblEnterPassword,
                                        text: $securityPolicyViewModel.group10198Text)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .foregroundColor(ColorConstants.Bluegray200)
                                .padding()
                                .keyboardType(.default)
                            Image("img_vector_bluegray_200")
                                .resizable()
                                .frame(width: 16.0, height: getRelativeHeight(13.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.vertical, getRelativeHeight(15.0))
                                .padding(.leading, getRelativeWidth(30.0))
                                .padding(.trailing, getRelativeWidth(13.0))
                            Spacer()
                        }
                        .onChange(of: securityPolicyViewModel.group10198Text) { newValue in

                            securityPolicyViewModel.isValidGroup10198Text = newValue
                                .isValidPassword(isMandatory: true)
                        }
                        .frame(width: 396.0, height: getRelativeHeight(44.0), alignment: .center)
                        .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                bottomRight: 6.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 1))
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(ColorConstants.WhiteA700))
                        if !securityPolicyViewModel.isValidGroup10198Text {
                            Text("Please enter valid password.")
                                .foregroundColor(Color.red)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .frame(width: 396.0, height: getRelativeHeight(44.0),
                                       alignment: .center)
                        }
                    }
                }
                .frame(width: 397.0, height: getRelativeHeight(44.0), alignment: .center)
                .padding(.top, getRelativeHeight(9.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack(alignment: .leading, spacing: 0) {
                    Text(StringConstants.kMsgSequrityQuesti)
                        .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                        .fontWeight(.medium)
                        .foregroundColor(ColorConstants.Bluegray900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: 132.0, height: getRelativeHeight(16.0),
                               alignment: .topLeading)
                        .padding(.trailing)
                }
                .frame(width: 397.0, height: getRelativeHeight(16.0), alignment: .center)
                .padding(.top, getRelativeHeight(21.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack {
                    Picker(StringConstants.kMsgWhatWasYourF,
                           selection: $securityPolicyViewModel.group10198OnePicker1) {
                        ForEach(securityPolicyViewModel.group10198OnePicker1Values,
                                id: \.self) { value in
                            Text(value)
                        }
                    }
                    .foregroundColor(ColorConstants.Bluegray200)
                    .font(.system(size: getRelativeHeight(16)))
                    .pickerStyle(MenuPickerStyle())
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblAnswer)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray800)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 53.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        HStack {
                            TextField(StringConstants.kLblPluto,
                                      text: $securityPolicyViewModel.group10198twoText)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .foregroundColor(ColorConstants.Bluegray200)
                                .padding()
                        }
                        .frame(width: 396.0, height: getRelativeHeight(44.0), alignment: .leading)
                        .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                bottomRight: 6.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 1))
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(ColorConstants.WhiteA700))
                        .padding(.top, getRelativeHeight(9.0))
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .center)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                    .padding(.top, getRelativeHeight(20.0))
                    Button(action: {}, label: {
                        HStack(spacing: 0) {
                            Text(StringConstants.kLblSignIn2)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .fontWeight(.medium)
                                .padding(.horizontal, getRelativeWidth(30.0))
                                .padding(.vertical, getRelativeHeight(17.0))
                                .foregroundColor(ColorConstants.WhiteA700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: 396.0, height: getRelativeHeight(50.0),
                                       alignment: .center)
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0)
                                        .fill(ColorConstants.BlueA700))
                                .padding(.top, getRelativeHeight(24.0))
                        }
                    })
                    .frame(width: 396.0, height: getRelativeHeight(50.0), alignment: .center)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0)
                            .fill(ColorConstants.BlueA700))
                    .padding(.top, getRelativeHeight(24.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(208.0), alignment: .center)
                .padding(.vertical, getRelativeHeight(8.0))
                .padding(.horizontal, getRelativeWidth(16.0))
            }
            .frame(width: 310.0, alignment: .topLeading)
            .background(ColorConstants.Gray51)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: 310.0, height: UIScreen.main.bounds.height)
        .background(ColorConstants.Gray51)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct SecurityPolicyView_Previews: PreviewProvider {
    static var previews: some View {
        SecurityPolicyView()
    }
}
