import Foundation
import SwiftUI

class SecurityPolicyViewModel: ObservableObject {
    @Published var emailText: String = ""
    @Published var isValidEmailText: Bool = true
    @Published var group10198Text: String = ""
    @Published var isValidGroup10198Text: Bool = true
    @Published var group10198OnePicker1: String = "Option 1"
    @Published var group10198OnePicker1Values: [String] = ["Option 1", "Option 2", "Option 3"]
    @Published var group10198twoText: String = ""
}
