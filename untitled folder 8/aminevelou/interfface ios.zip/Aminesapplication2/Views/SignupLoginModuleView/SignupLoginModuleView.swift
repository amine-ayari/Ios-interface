import SwiftUI

struct SignupLoginModuleView: View {
    @StateObject var signupLoginModuleViewModel = SignupLoginModuleViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack(alignment: .leading, spacing: 0) {
                VStack {
                    HStack {
                        HStack {
                            Image("img_leftside")
                                .resizable()
                                .frame(width: 54.0, height: getRelativeHeight(21.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .clipShape(Capsule())
                            Spacer()
                            Image("img_rightside")
                                .resizable()
                                .frame(width: 66.0, height: getRelativeHeight(11.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(4.0))
                        }
                        .frame(width: getRelativeWidth(392.0), height: getRelativeHeight(21.0),
                               alignment: .leading)
                    }
                    .frame(width: 392.0, height: getRelativeHeight(21.0), alignment: .leading)
                    .padding(.leading, getRelativeWidth(5.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(21.0), alignment: .center)
                .padding(.top, getRelativeHeight(12.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        Image("img_arrowleft")
                            .resizable()
                            .frame(width: 12.0, height: getRelativeWidth(12.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.top, getRelativeHeight(4.0))
                            .padding(.bottom, getRelativeHeight(7.0))
                            .onTapGesture {
                                self.presentationMode.wrappedValue.dismiss()
                            }
                        Text(StringConstants.kLblEmailSignIn)
                            .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(24.0)))
                            .fontWeight(.semibold)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 140.0, height: getRelativeHeight(24.0),
                                   alignment: .topLeading)
                            .padding(.leading, getRelativeWidth(110.0))
                    }
                    .frame(width: 262.0, height: getRelativeHeight(24.0), alignment: .leading)
                    .padding(.leading, getRelativeWidth(6.0))
                    .padding(.trailing, getRelativeWidth(6.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(24.0), alignment: .center)
                .padding(.top, getRelativeHeight(29.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblEmail)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 40.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.trailing)
                        Group {
                            HStack {
                                TextField(StringConstants.kMsgEnterYourEmai,
                                          text: $signupLoginModuleViewModel.group10198Text)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Bluegray200)
                                    .padding()
                                    .keyboardType(.emailAddress)
                            }
                            .onChange(of: signupLoginModuleViewModel.group10198Text) { newValue in

                                signupLoginModuleViewModel.isValidGroup10198Text = newValue
                                    .isValidEmail(isMandatory: true)
                            }
                            .frame(width: 396.0, height: getRelativeHeight(44.0),
                                   alignment: .leading)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.WhiteA700))
                            .padding(.top, getRelativeHeight(9.0))
                            if !signupLoginModuleViewModel.isValidGroup10198Text {
                                Text("Please enter valid email.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                    .frame(width: 396.0, height: getRelativeHeight(44.0),
                                           alignment: .leading)
                            }
                        }
                    }
                    .frame(width: 396.0, height: getRelativeHeight(69.0), alignment: .center)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(69.0), alignment: .center)
                .padding(.top, getRelativeHeight(38.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack(alignment: .leading, spacing: 0) {
                    Text(StringConstants.kLblPassword)
                        .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                        .fontWeight(.medium)
                        .foregroundColor(ColorConstants.Bluegray900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: 70.0, height: getRelativeHeight(16.0), alignment: .topLeading)
                        .padding(.trailing)
                }
                .frame(width: 397.0, height: getRelativeHeight(16.0), alignment: .center)
                .padding(.top, getRelativeHeight(19.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                VStack {
                    Group {
                        HStack {
                            SecureField(StringConstants.kLblEnterPassword,
                                        text: $signupLoginModuleViewModel.group10198oneText)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .foregroundColor(ColorConstants.Bluegray200)
                                .padding()
                                .keyboardType(.default)
                            Image("img_vector_bluegray_200")
                                .resizable()
                                .frame(width: 16.0, height: getRelativeHeight(13.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.vertical, getRelativeHeight(15.0))
                                .padding(.leading, getRelativeWidth(30.0))
                                .padding(.trailing, getRelativeWidth(13.0))
                            Spacer()
                        }
                        .onChange(of: signupLoginModuleViewModel.group10198oneText) { newValue in

                            signupLoginModuleViewModel.isValidGroup10198oneText = newValue
                                .isValidPassword(isMandatory: true)
                        }
                        .frame(width: 396.0, height: getRelativeHeight(44.0), alignment: .center)
                        .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                bottomRight: 6.0)
                                .stroke(ColorConstants.Bluegray100,
                                        lineWidth: 1))
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(ColorConstants.WhiteA700))
                        if !signupLoginModuleViewModel.isValidGroup10198oneText {
                            Text("Please enter valid password.")
                                .foregroundColor(Color.red)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .frame(width: 396.0, height: getRelativeHeight(44.0),
                                       alignment: .center)
                        }
                    }
                    HStack {
                        CheckboxField(idValue: StringConstants.kLblRememberMe,
                                      label: StringConstants.kLblRememberMe,
                                      color: ColorConstants.Bluegray100,
                                      isMarked: $signupLoginModuleViewModel.inputlabelsCheckbox)
                            .minimumScaleFactor(0.5)
                            .frame(width: 122.0, height: getRelativeHeight(20.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 2.5, topRight: 2.5, bottomLeft: 2.5,
                                                    bottomRight: 2.5)
                                    .stroke(ColorConstants.Bluegray100,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 2.5, topRight: 2.5, bottomLeft: 2.5,
                                                       bottomRight: 2.5)
                                    .fill(ColorConstants.WhiteA700))
                        Spacer()
                        Text(StringConstants.kMsgForgotPassword)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(14.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.BlueA700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 114.0, height: getRelativeHeight(14.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(4.0))
                    }
                    .frame(width: 390.0, height: getRelativeHeight(20.0), alignment: .center)
                    .padding(.top, getRelativeHeight(9.0))
                    .padding(.trailing, getRelativeWidth(7.0))
                    Button(action: {}, label: {
                        HStack(spacing: 0) {
                            Text(StringConstants.kLblSignIn)
                                .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                                .fontWeight(.medium)
                                .padding(.horizontal, getRelativeWidth(30.0))
                                .padding(.vertical, getRelativeHeight(17.0))
                                .foregroundColor(ColorConstants.WhiteA700)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: 396.0, height: getRelativeHeight(50.0),
                                       alignment: .center)
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0)
                                        .fill(ColorConstants.BlueA700))
                                .padding(.top, getRelativeHeight(25.0))
                        }
                    })
                    .frame(width: 396.0, height: getRelativeHeight(50.0), alignment: .center)
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0)
                            .fill(ColorConstants.BlueA700))
                    .padding(.top, getRelativeHeight(25.0))
                    HStack {
                        Divider()
                            .frame(width: 130.0, height: getRelativeHeight(1.0), alignment: .bottom)
                            .background(ColorConstants.Bluegray200)
                            .padding(.top, getRelativeHeight(8.0))
                            .padding(.bottom, getRelativeHeight(6.0))
                        Text(StringConstants.kMsgOrContinueWit)
                            .font(FontScheme.kGilroyRegular(size: getRelativeHeight(16.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Bluegray200)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 121.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.leading, getRelativeWidth(8.0))
                        Divider()
                            .frame(width: 129.0, height: getRelativeHeight(1.0), alignment: .bottom)
                            .background(ColorConstants.Bluegray200)
                            .padding(.top, getRelativeHeight(8.0))
                            .padding(.bottom, getRelativeHeight(6.0))
                            .padding(.leading, getRelativeWidth(8.0))
                        Spacer()
                    }
                    .frame(width: 396.0, height: getRelativeHeight(16.0), alignment: .center)
                    .padding(.top, getRelativeHeight(28.0))
                    HStack {
                        Image("img_google1")
                            .resizable()
                            .frame(width: 23.0, height: getRelativeWidth(23.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.vertical, getRelativeHeight(13.0))
                            .padding(.leading, getRelativeWidth(111.0))
                        Text(StringConstants.kMsgSignInWithGo)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.BlueA700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 143.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(17.0))
                            .padding(.bottom, getRelativeHeight(16.0))
                            .padding(.leading, getRelativeWidth(8.0))
                            .padding(.trailing, getRelativeWidth(110.0))
                    }
                    .onTapGesture {
                        signupLoginModuleViewModel.googleSignIn()
                    }
                    .frame(width: 396.0, height: getRelativeHeight(50.0), alignment: .center)
                    .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                            bottomRight: 6.0)
                            .stroke(ColorConstants.BlueA700,
                                    lineWidth: 1))
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0)
                            .fill(Color.clear.opacity(0.7)))
                    .padding(.top, getRelativeHeight(29.0))
                    .padding(.horizontal, getRelativeWidth(1.0))
                    HStack {
                        ZStack {
                            Image("img_vector_gray_52")
                                .resizable()
                                .frame(width: 11.0, height: getRelativeHeight(19.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(4.5))
                                .padding(.leading, getRelativeWidth(9.0))
                        }
                        .hideNavigationBar()
                        .onTapGesture {
                            signupLoginModuleViewModel.facebookSignIn()
                        }
                        .frame(width: 24.0, height: getRelativeWidth(24.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 3.0, topRight: 3.0, bottomLeft: 3.0,
                                                   bottomRight: 3.0)
                                .fill(ColorConstants.Blue700))
                        .padding(.vertical, getRelativeHeight(13.0))
                        .padding(.leading, getRelativeWidth(101.0))
                        Text(StringConstants.kMsgSignInWithFa)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.BlueA700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 162.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(18.0))
                            .padding(.bottom, getRelativeHeight(16.0))
                            .padding(.leading, getRelativeWidth(8.0))
                            .padding(.trailing, getRelativeWidth(101.0))
                    }
                    .frame(width: 396.0, height: getRelativeHeight(50.0), alignment: .center)
                    .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                            bottomRight: 6.0)
                            .stroke(ColorConstants.BlueA700,
                                    lineWidth: 1))
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0)
                            .fill(Color.clear.opacity(0.7)))
                    .padding(.top, getRelativeHeight(16.0))
                    .padding(.horizontal, getRelativeWidth(1.0))
                    HStack {
                        ZStack {
                            Image("img_vector_white_a700")
                                .resizable()
                                .frame(width: 15.0, height: getRelativeWidth(15.0),
                                       alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(4.15))
                                .padding(.bottom, getRelativeHeight(4.85))
                                .padding(.horizontal, getRelativeWidth(4.09))
                        }
                        .hideNavigationBar()
                        .frame(width: 24.0, height: getRelativeWidth(24.0), alignment: .center)
                        .background(RoundedCorners(topLeft: 1.0, topRight: 1.0, bottomLeft: 1.0,
                                                   bottomRight: 1.0)
                                .fill(ColorConstants.LightBlue800))
                        .padding(.vertical, getRelativeHeight(13.0))
                        .padding(.leading, getRelativeWidth(109.0))
                        Text(StringConstants.kMsgSignInWithLi)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.BlueA700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: 147.0, height: getRelativeHeight(16.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(18.0))
                            .padding(.bottom, getRelativeHeight(16.0))
                            .padding(.leading, getRelativeWidth(8.0))
                            .padding(.trailing, getRelativeWidth(108.0))
                    }
                    .frame(width: 396.0, height: getRelativeHeight(50.0), alignment: .center)
                    .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                            bottomRight: 6.0)
                            .stroke(ColorConstants.BlueA700,
                                    lineWidth: 1))
                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                               bottomRight: 6.0)
                            .fill(Color.clear.opacity(0.7)))
                    .padding(.top, getRelativeHeight(16.0))
                    .padding(.horizontal, getRelativeWidth(1.0))
                    Text(StringConstants.kMsgDonTHaveAnA)
                        .font(FontScheme.kGilroyRegular(size: getRelativeHeight(16.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.Gray900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.leading)
                        .frame(width: 244.0, height: getRelativeHeight(16.0),
                               alignment: .topLeading)
                        .padding(.top, getRelativeHeight(21.0))
                        .padding(.horizontal, getRelativeWidth(77.0))
                }
                .frame(width: 397.0, height: getRelativeHeight(441.0), alignment: .center)
                .padding(.vertical, getRelativeHeight(9.0))
                .padding(.horizontal, getRelativeWidth(16.0))
            }
            .frame(width: 310.0, alignment: .topLeading)
            .background(ColorConstants.Gray51)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: 310.0, height: UIScreen.main.bounds.height)
        .background(ColorConstants.Gray51)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct SignupLoginModuleView_Previews: PreviewProvider {
    static var previews: some View {
        SignupLoginModuleView()
    }
}
