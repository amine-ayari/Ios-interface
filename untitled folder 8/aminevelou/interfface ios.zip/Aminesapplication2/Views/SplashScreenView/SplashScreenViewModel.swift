import Foundation
import SwiftUI

class SplashScreenViewModel: ObservableObject {}
