import Foundation
import SwiftUI

class TermsAndConditionsViewModel: ObservableObject {}
