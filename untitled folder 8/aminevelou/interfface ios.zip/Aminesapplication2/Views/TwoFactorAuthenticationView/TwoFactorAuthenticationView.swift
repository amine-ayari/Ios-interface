import SwiftUI

struct TwoFactorAuthenticationView: View {
    @StateObject var twoFactorAuthenticationViewModel = TwoFactorAuthenticationViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                HStack {
                    HStack {
                        Image("img_leftside")
                            .resizable()
                            .frame(width: 54.0, height: getRelativeHeight(21.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .clipShape(Capsule())
                        Spacer()
                        Image("img_rightside")
                            .resizable()
                            .frame(width: 66.0, height: getRelativeHeight(11.0), alignment: .center)
                            .scaledToFit()
                            .clipped()
                            .padding(.top, getRelativeHeight(5.0))
                            .padding(.bottom, getRelativeHeight(4.0))
                    }
                    .frame(width: getRelativeWidth(392.0), height: getRelativeHeight(21.0),
                           alignment: .leading)
                }
                .frame(width: 392.0, height: getRelativeHeight(21.0), alignment: .leading)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                Image("img_vector_blue_a700_60x38")
                    .resizable()
                    .frame(width: 38.0, height: getRelativeHeight(60.0), alignment: .center)
                    .scaledToFit()
                    .clipped()
                    .padding(.top, getRelativeHeight(246.0))
                    .padding(.horizontal, getRelativeWidth(16.0))
                Text(StringConstants.kMsgOtpVerificatio)
                    .font(FontScheme.kGilroySemiBold(size: getRelativeHeight(24.0)))
                    .fontWeight(.semibold)
                    .foregroundColor(ColorConstants.BlueA700)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: 177.0, height: getRelativeHeight(24.0), alignment: .topLeading)
                    .padding(.top, getRelativeHeight(15.0))
                    .padding(.horizontal, getRelativeWidth(16.0))
                Text(StringConstants.kMsgOtpIsSendTo)
                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(18.0)))
                    .fontWeight(.medium)
                    .foregroundColor(ColorConstants.Gray700)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: 263.0, height: getRelativeHeight(18.0), alignment: .topLeading)
                    .padding(.top, getRelativeHeight(37.0))
                    .padding(.horizontal, getRelativeWidth(16.0))
                Image("img_frame9880")
                    .resizable()
                    .frame(width: 320.0, height: getRelativeHeight(52.0), alignment: .center)
                    .scaledToFit()
                    .clipped()
                    .padding(.top, getRelativeHeight(29.0))
                    .padding(.horizontal, getRelativeWidth(16.0))
                Button(action: {}, label: {
                    HStack(spacing: 0) {
                        Text(StringConstants.kLblVerifyOtp)
                            .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                            .fontWeight(.medium)
                            .padding(.horizontal, getRelativeWidth(30.0))
                            .padding(.vertical, getRelativeHeight(17.0))
                            .foregroundColor(ColorConstants.WhiteA700)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: 396.0, height: getRelativeHeight(50.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(ColorConstants.BlueA700))
                            .padding(.top, getRelativeHeight(32.0))
                            .padding(.horizontal, getRelativeWidth(16.0))
                    }
                })
                .frame(width: 396.0, height: getRelativeHeight(50.0), alignment: .center)
                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                           bottomRight: 6.0)
                        .fill(ColorConstants.BlueA700))
                .padding(.top, getRelativeHeight(32.0))
                .padding(.horizontal, getRelativeWidth(16.0))
                Text(StringConstants.kMsgDidnTRecieved)
                    .font(FontScheme.kGilroyMedium(size: getRelativeHeight(16.0)))
                    .fontWeight(.medium)
                    .foregroundColor(ColorConstants.BlueA700)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: 231.0, height: getRelativeHeight(16.0), alignment: .topLeading)
                    .padding(.vertical, getRelativeHeight(28.0))
                    .padding(.horizontal, getRelativeWidth(16.0))
            }
            .frame(width: 310.0, alignment: .topLeading)
            .background(ColorConstants.Gray51)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: 310.0, height: UIScreen.main.bounds.height)
        .background(ColorConstants.Gray51)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct TwoFactorAuthenticationView_Previews: PreviewProvider {
    static var previews: some View {
        TwoFactorAuthenticationView()
    }
}
