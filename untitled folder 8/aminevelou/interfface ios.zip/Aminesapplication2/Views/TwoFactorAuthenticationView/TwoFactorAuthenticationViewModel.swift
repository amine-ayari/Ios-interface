import Foundation
import SwiftUI

class TwoFactorAuthenticationViewModel: ObservableObject {}
